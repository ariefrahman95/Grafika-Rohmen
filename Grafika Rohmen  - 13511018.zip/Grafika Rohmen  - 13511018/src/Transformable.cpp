#include "Transformable.hpp"
using namespace std;

void Transformable::Scale( const float scale ) {

}

void Transformable::Translate( const float dx, const float dy ) {

}

void Transformable::Rotate( const float angle ) {

}

const std::vector<Point>& Transformable::GetPoints() const {

}

std::vector<Point>& Transformable::GetPointsRef() const {

}