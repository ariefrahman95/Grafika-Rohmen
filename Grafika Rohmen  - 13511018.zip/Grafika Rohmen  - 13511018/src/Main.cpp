#include "Game.hpp"
using namespace std;

int main()
{
	Game g;
	g.Run();
}
