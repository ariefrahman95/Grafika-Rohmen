Compile dengan command berikut:
g++ -m32 -o clipping clipping.c libopenbgi.a -lgdi32

Jalankan dengan command berikut:
clipping